import torch
from torch.utils.data import DataLoader
from torchvision import transforms
from patchDataset import patchDataset
from model_seclect import Model_get
from utils.frame_work_general import MyFrame
from PIL import Image
import os
import glob
from tqdm import tqdm
import argparse
import numpy as np

def load_model(model_name, weights, device):
    model= Model_get(Model_select=model_name)
    model=model().cuda()
    model.to(device)
    model= torch.nn.DataParallel(model, device_ids=range(torch.cuda.device_count()))
    model.load_state_dict(torch.load(weights, map_location=device, weights_only=True))
    model.eval()
    return model

def infer(model, file_path, output_dir, device):
    pred_dir=os.path.join(output_dir, "predictions")
    os.makedirs(pred_dir, exist_ok=True)

    with open(file_path, 'r') as f:
        image_paths = [line.strip().split(' @')[0] for line in f.readlines() if line.strip()]

    for img_path in tqdm(image_paths, desc="Inference"):
        img_name = os.path.basename(img_path)
        path=os.path.join(os.path.dirname(file_path), img_path)
        image = Image.open(path).convert('RGB') # H,W 

        if image.size != (512, 512):  
            image = image.resize((512, 512), Image.BICUBIC)

        image_np = np.array(image)
        image_np = image_np.transpose([2, 0, 1]).astype(np.float32) #C, H, W
        image_tensor = torch.Tensor(image_np)

        with torch.no_grad():
            pred, logits = model(image_tensor.unsqueeze(0))

        pred = pred.cpu().data.numpy().squeeze()
        pred_img = (pred * 255).astype(np.uint8)
        pred_img = Image.fromarray(pred_img)
        pred_img.save(f"{pred_dir}/{img_name}")  

def main():
    parser = argparse.ArgumentParser(description='Inference for 512x512 images')
    parser.add_argument('--model', type=str, default='MSMDFF_USE_SCMD', help='The model you want to use')
    parser.add_argument('--weights', type=str, default='None', help='Path to the model weights') 
    parser.add_argument('--file', type=str, default='./', help='Path to the test.txt')
    parser.add_argument('--output', type=str, default='./predictions', help='Directory to save predictions')
    args = parser.parse_args()

    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model=load_model(args.model, args.weights, DEVICE)


    infer(model, args.file, args.output, DEVICE)

if __name__ == "__main__":
    main()