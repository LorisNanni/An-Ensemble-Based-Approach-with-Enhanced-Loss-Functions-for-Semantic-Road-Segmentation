This repository contains the code used to perform all the training of the networks described in the paper:

**"Mapping the Unmapped: Deep Learning Ensembles and Novel Loss Functions for Scalable Road Segmentation from Aerial Imagery"**.

The code is based on the original implementation from [MSMDFF-NET](https://github.com/wycloveinfall/MSMDFF-NET), with modifications to suit our specific needs. It trains networks using various loss functions that exploit topological properties of roads.

## Requirements
To set up the environment, please refer to the `requirements-train.txt` and `requirements-infer.txt` files provided in the repository.
## Training Environment
The training environment had:
- Pytorch: 2.2.1
- Torchvision: 0.17.1
- CUDA: 12.1

## Inference Environment
The inference environment had:
- Pytorch: 2.6.0
- Torchvision: 0.21.0
- CUDA: 12.6

## Dataset Structure

The datasets for the test described on the paper were organized in this way:

```bash
data/train/
    ├── MassachussetsRoads/
    │   ├── test/
    │   ├── test_labels/
    │   ├── train/
    │   ├── train/labels/
    │   ├── train.txt
    │   ├── val.txt
    │   ├── val.patches.txt
    │   └── test.txt
    ├── DeepGlobe/
    │   ├── train.txt
    │   ├── train.txt
    │   ├── val.txt
    │   ├── val.patches.txt
    │   └── test.txt
    ├── SpaceNet/
    │   ├── AOI_2_Vegas/
    │   │   ├── train_src/
    │   │   └── label_width24/
    │   ├── AOI_3_Paris/
    │   │   ├── train_src/
    │   │   └── label_width24/
    │   ├── AOI_4_Shanghai/
    │   │   ├── train_src/
    │   │   └── label_width24/
    │   ├── AOI_5_Khartoum/
    │   │   ├── train_src/
    │   │   └── label_width24/
    │   ├── train.txt
    │   ├── val.txt
    │   ├── val.patches.txt
    │   └── test.txt
    ├── CornioloDataset/
    │   ├── images/
    │   ├── masks/
    │   └── test.txt
    └── Boston/
    │   ├── images/
    │   ├── masks/
    │   └── test.txt

```

For DeepGlobe the images are inside the main directory.

For example, in the `train.txt` file of SpaceNet, you might find a line like this:

```bash
AOI_2_Vegas/train_src/SN3_roads_train_AOI_2_Vegas_PS-RGB_img302_sat.png @AOI_2_Vegas/label_width24/SN3_roads_train_AOI_2_Vegas_roads_label_img302_mask.png
```
The required structure should be:

```bash
path/to/src/image @path/to/label/image
```
Make sure that the image path and label mask path are separated by the `@` symbol preceeded by a space, as shown in the example above.

If you want to download the datasets used in our tests, please follow the links present in our paper.

## SpaceNet Preprocessing
For the preprocessing of the SpaceNet dataset, please refer to the [MSMDFF GitHub repository](https://github.com/wycloveinfall/MSMDFF-NET).

- Convert SpaceNet 11-bit images to 8-bit Images.

```bash
cd MSMDFF-NET-main
python data/data_tools/SP_datatools/1.convert_to_8bit.py
```

- Create road centerline.

```bash
cd MSMDFF-NET-main
python data/data_tools/SP_datatools/2.cerete_label.py
```

- Create road masks.

```bash
cd MSMDFF-NET-main
python data/data_tools/SP_datatools/3.fill_center_line.py 
```

- Select Train files. Not all JSON files can generate masks, so it is necessary to filter out paired training samples.

```bash
cd MSMDFF-NET-main
python data/data_tools/SP_datatools/4.choose_train_flie.py 
```

## Datasets 
To download the datasets in the format we used, here are the links:

- For MassachussetsRoads, DeepGlobe, SpaceNet and Augmented MassachussetsRoads: https://zenodo.org/records/15039041
- For Boston and CornioloDataset: https://zenodo.org/records/11107140

## Configuration Check

Before starting the training process, please ensure to check the base settings. These are located in the following file:

```bash
cfg_file/cfg_link_to_data_api.json
```

If the training files are launched without parameters, the settings from this file will be used by default.

For more details (Only the parameters changed from the default github are mentioned):

- DIR_SETTING:
    - train_sample : the path to the .txt files (Here "data/train/DeepGlobe")
    - trainProcessdata : the path to the output directory (Here "train_data_cache")
    - root_dir : the path to the .txt files (Here "data/train/DeepGlobe")
- OPTIMIZER_SETTINGS:
    - LOSS_FCT : name of the loss to use (Here "topological_loss")
    - OPTIMIZER : Adam(AMSGrad)
    - LR_SCHEDULER : POLY
    - WARMUP_EPOCHS : Here set to 0.
- TRAIN_SETTING:
    - DATA_TYPE : choose the dataset between "DeepGlobe_512_512", "spacenet_512_512" and "Massachusetts_512_512"
    - BATCH_SIZE : training batch size (Here 6)
    - IOU_THRESHOLD_LOSS : the threshold to use (Here 0.375)
    - EPOCHS : maximum number of training epocs (Here 200)

## Split files
For the training process, at least two files per dataset should be provided:
- train.txt
- val_patches.txt

A third file, test.txt, is used to list the test files.

### File structure
Each split file follows a specific format, where each line represents an entry structured as:
```bash
path/to/image_src @path/to/corresponding/mask
```
The val_patches.txt file is used by the framework and extends this format by adding a specific patch identifier (%x_y) at the end of each line, indicating the exact patch to be used.

### Split modifications
If you need to modify the dataset split, ensure that the formatting described above is maintained.

You can list the new validation split in val.txt without the additional %x_y identifier. Then, run one of the following scripts to prepare the validation split accordingly:
- prepare_dg_val.py
- prepare_ms_val.py
- prepare_sp_val.py

## Training
To start the training process, simply execute the following command:

```bash
python train.py
```
If you wish to run the training with different parameters from the default settings, you can use the following command:
```bash
python train.py --model='name_of_the_model' --loss='name_of_the_loss' --threshold=value_of_the_threshold --dataset='dataset_512_512' --lr='Learning_rate_scheduler' --optimizer='optimizer'
```

Here are the values used in these tests:
- model:
    - MSMDFF_USE_SCMD
    - CoANet_USE_SCMD
    - CoANet_USE_SCM
- loss:
    - dice_bce_loss
    - topological_loss
    - topological_road_curvature_loss
    - modified_topological_road_curvature_loss
- threshold:
    - 0.375
- dataset:
    - DeepGlobe_512_512
    - spacenet_512_512
    - Massachusetts_512_512
- lr:
    - StepLR
    - MultiStepLR
    - ExponentialLR
    - CosineAnnealingLR
    - ReduceLRonPlateau
    - LambdaLR
    - POLY 
- optimizer:
    - SGD
    - ASGD
    - Rprop
    - Adagrad
    - Adadelta
    - RMSprop
    - Adam(AMSGrad)

If you left a option blank, the default one will be used.

The training will save two models: one from the last trained epoch and the one with the highest IoU on the validation set. The results are saved on trainProcessdata variable in the cfg_link_to_data_api.json.

## Training with augmented Massachusetts dataset
To begin have this structure:
```bash
data/train/
    ├── roadsegmentation/
    │   ├── mask100/
    │   ├── train100/
    │   ├── train.txt
    │   └── val.txt

```
Then execute:

```bash
python train_512.py
```

The parameters used are the same as those in `train.py`, with the addition of the `--k` parameter. This parameter specifies the number of images to be seen per epoch. If `k >= 99670` or `k` is set to `Null`, the entire training set will be used. For our tests we've used `k=20004`.

This file is designed to run only on the augmented Massachusetts dataset.

## Inference

There are two files for performing inference:

- `inference.py`: For original size images.
- `inference512.py`: For images resized to 512x512 or similar.

Both files output grayscale images corresponding to the integer values of the logits. If true binarization is required, this must be performed separately.

### `inference.py`

This script processes the original images, cropping them into 512x512 patches and adding padding if necessary. It can also generate the corresponding masks.

### Parameters:
- `model`: Name of the model to be used.
- `weights`: Path to the model's weights file.
- `file`: Path to the `.txt` file containing the test split (always formatted as "path/src @path/label").
- `output`: Directory for saving the output.
- `masks`: Set to `True` if the corresponding masks should be generated (set to `False` if not).
- `patch_size` : Dimension of the patch (Set to default to 512x512)
- `batch_size` : Dimension of the batch (Set to defaul to 1)

### `inference512.py`

This script processes images that are already resized to 512x512 or are close to this size (resizing them if necessary).

### Parameters:
- `model`: Name of the model to be used.
- `weights`: Path to the model's weights file.
- `file`: Path to the `.txt` file containing the test split (always formatted as "path/src @path/label").
- `output`: Directory for saving the output.

## Testing File

The file for performing an initial test is `test.py`. This script calculates the metrics for the predicted images. The input directory should contain two subdirectories: `predictions` and `masks`.

### Parameters:
- `path`: path to the directory containing both `predictions` and `masks` folders.
- `thresh`: threshold parameter for binarization.
- `mask_ext`: Extension for the masks, if different from the predictions. If the extension differs between predictions and masks, the program will not function correctly (e.g., '.png').


Since these scripts also consider images with padding, the results obtained are not the exact ones. To obtain the true results, it is necessary to reconstruct the original image without padding. However, these files can provide an initial impression of the model's performance.

## Changes from original framework

To see all the modifications made from the original [framework](https://github.com/wycloveinfall/MSMDFF-NET), refer to the file `changes.txt`

## Acknowledgement
We would like to thank the authors of MSMDFF [(link github)](https://github.com/wycloveinfall/MSMDFF-NET) for providing the original codebase, which served as the foundation for our work. Their contributions have been invaluable in enabling our research and development.