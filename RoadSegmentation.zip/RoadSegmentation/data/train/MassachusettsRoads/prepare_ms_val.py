def prepare_ms_val(input_file, output_file):
    with open(input_file, 'r') as infile:
        lines = infile.readlines()
    pool = [0, 1, 2]
    with open(output_file, 'w') as outfile:
        for line in lines:
            line = line.strip()
            for x in pool:
                for y in pool:
                    modified_line = f"{line} %{x}_{y}\n"
                    outfile.write(modified_line)

input_file = 'val.txt'
output_file = 'val_patches.txt'
prepare_ms_val(input_file, output_file)