import os
import sys
import math
import numpy as np
from PIL import Image
from osgeo import gdal
from pathlib import Path

gdal.UseExceptions()

def ReadTifImg(filename):
    '''Function to read TIF images and return projection, geotransform, and image data.'''
    dataset = gdal.Open(filename) 
    im_width = dataset.RasterXSize 
    im_height = dataset.RasterYSize  
    im_geotrans = dataset.GetGeoTransform() 
    im_proj = dataset.GetProjection()  
    im_data = dataset.ReadAsArray(0, 0, im_width, im_height) 
    del dataset
    return im_proj, im_geotrans, im_data

if __name__ == '__main__':
    root_dir = Path.cwd() 
    folders = ['test', 'test_labels', 'val', 'val_labels', 'train', 'train_labels']

    for folder in folders:
        input_dir = root_dir / folder
        output_dir = root_dir / 'PNG' / folder
        os.makedirs(output_dir, exist_ok=True) 
        
        for subfolder in os.listdir(input_dir):
            subfolder_path = input_dir / subfolder
            if os.path.isdir(subfolder_path):
                output_subfolder = output_dir / subfolder
                os.makedirs(output_subfolder, exist_ok=True)
                
                for filename in os.listdir(subfolder_path):
                    if filename.endswith('.tif') or filename.endswith('.tiff'):
                        tif_file_path = subfolder_path / filename
                        _, _, img = ReadTifImg(tif_file_path)

                        if img.shape[0] == 3:
                            img = img.transpose(1, 2, 0)

                        img_name = filename.split('.')[0] + '.png'
                        output_png_path = output_subfolder / img_name
                        image = Image.fromarray(img)
                        image.save(output_png_path, format='PNG')

    print('Done\n')