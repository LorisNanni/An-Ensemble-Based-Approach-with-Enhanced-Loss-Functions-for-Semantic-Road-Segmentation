# -*-coding:utf-8-*-

import os
from pathlib import Path
import shutil
from sys import stderr

from tqdm import trange

if __name__ == '__main__':

    root_dir = Path.cwd() / 'data' / 'train' / 'SpaceNet'
    if not root_dir.exists():
        print('Run this script from the root of the MSMDFF-NET repository, with the SpaceNet 3 dataset stored in', Path('data') / 'train' / 'SpaceNet', file=stderr)
        print('The current working directory is', Path.cwd(), file=stderr)
        exit(1)

    for city in 'AOI_2_Vegas', 'AOI_3_Paris', 'AOI_4_Shanghai', 'AOI_5_Khartoum':
        city_file = root_dir / city
        RGB_8bit = city_file / 'RGB-8bit'
        center_line_file = city_file / 'label_center_line'
        out_image_file = city_file / 'train_src'
        os.makedirs(out_image_file,exist_ok=True)
        with trange(len(os.listdir(center_line_file))) as t:
            for __file,index in zip(os.listdir(center_line_file),t):
                __file = __file.replace('_roads_label_','_PS-RGB_').replace('.tif','_sat.tif')
                shutil.move(RGB_8bit / __file,out_image_file / __file)
        shutil.rmtree(RGB_8bit,ignore_errors=True)