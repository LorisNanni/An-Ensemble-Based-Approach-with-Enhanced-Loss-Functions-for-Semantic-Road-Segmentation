# --coding:utf-8--
# PROJECT_NAME:MSMDFF-Net_open
# file_name:__init__.py.py
# log_user:wychasee
# author:by **
# date:2024/4/10
# time:上午8:38
from .roadcnn import Model as RoadCNN
