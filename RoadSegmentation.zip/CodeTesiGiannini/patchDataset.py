import torch
from torch.utils.data import Dataset
import torchvision.transforms.functional as F
from PIL import Image
import os
import numpy as np

class patchDataset(Dataset):
    def __init__(self, file_path, patch_size=512, transform=None, masks=False):
        self.data_path=os.path.dirname(file_path)
        with open(file_path, 'r') as f:
            lines = f.readlines()
            if masks == False:
                self.image_names = [line.split(' @')[0] for line in lines]
                self.image_paths = self.image_names
            else:
                self.image_names = [line.split(' @')[0] for line in lines]
                self.image_paths = [line.split(' @')[1] for line in lines]
        self.patch_size = patch_size
        self.transform = transform
        self.masks=masks

    def pad_image(self, image):
        pad_h = (self.patch_size - image.height % self.patch_size) % self.patch_size
        pad_w = (self.patch_size - image.width % self.patch_size) % self.patch_size
        pad_left = pad_w // 2
        pad_right = pad_w - pad_left
        pad_top = pad_h // 2
        pad_bottom = pad_h - pad_top
        return F.pad(image, (pad_left, pad_top, pad_right, pad_bottom), fill=0)

    def extract_patches(self, image):
        patches = []
        for i in range(0, image.height, self.patch_size):
            for j in range(0, image.width, self.patch_size):
                patch = image.crop((j, i, j + self.patch_size, i + self.patch_size))
                patches.append(patch)
        return patches

    def __getitem__(self, idx):
        img_name = self.image_paths[idx].strip()
        img_base_name = self.image_names[idx].strip()
        img_path = os.path.join(self.data_path, img_name)
        if self.masks==False:
            image = Image.open(img_path).convert("RGB")  # H,W,C
        else:
            image=Image.open(img_path).convert("L")
        padded_image = self.pad_image(image)
        patches = self.extract_patches(padded_image)
        if self.transform:
            patches = [self.transform(p) for p in patches]
        patches=np.array(patches, dtype=np.float32)
        if self.masks==False:
            patches =np.array([p.transpose(2, 0, 1) for p in patches])
        img_base_name = os.path.splitext(os.path.basename(img_base_name))[0]  
        img_base_name = "_".join(img_base_name.split("_")[:-1])
        return torch.tensor(patches), img_base_name

    def __len__(self):
        return len(self.image_paths)