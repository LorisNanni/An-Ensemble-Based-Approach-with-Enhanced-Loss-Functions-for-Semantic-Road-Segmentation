import torch
from torch.utils.data import DataLoader
from torchvision import transforms
from patchDataset import patchDataset
from model_seclect import Model_get
from utils.frame_work_general import MyFrame
from PIL import Image
import os
from tqdm import tqdm
import argparse
import numpy as np

def load_model(model_name, weights, device):
    model= Model_get(Model_select=model_name)
    model=model().cuda()
    #model = MSMDFF_Net_base(num_classes=1,init_block_SCMD=True,decoder_use_SCMD=True) #Alternatively put here the definition of the model you'll use.
    model.to(device)
    model= torch.nn.DataParallel(model, device_ids=range(torch.cuda.device_count()))
    model.load_state_dict(torch.load(weights, map_location=device, weights_only=True))
    model.eval()
    return model


def load_dataloader(file_path, patch_size, batch_size, masks):
    dataset = patchDataset(file_path, patch_size=patch_size, transform=None, masks=masks)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=1)
    return dataloader

def inference(model, dataloader, device, output_dir="output"):
    pred_dir=os.path.join(output_dir, "predictions")
    os.makedirs(pred_dir, exist_ok=True)
    with torch.no_grad():
        for batch_idx, (image_patches_batch, img_paths) in enumerate(tqdm(dataloader, desc="Processing batches", leave=True)):
            # patches_batch: (BATCH_SIZE, N_PATCHES, 3, PATCH_SIZE, PATCH_SIZE)
            for img_idx, (image_patches, img_path) in enumerate(zip(image_patches_batch, img_paths)):  
                image_patches = image_patches.to(device)
                for patch_idx, patch in enumerate(image_patches):
                    output, logits = model(patch.unsqueeze(0))  #output=post-sigmoid, logits=pre-sigmoid
                    pred = output.cpu().data.numpy().squeeze()
                    pred_img = (pred * 255).astype(np.uint8)
                    pred_img = Image.fromarray(pred_img)
                    img_name = os.path.basename(img_path)
                    pred_img.save(f"{pred_dir}/{img_name}_patch_{patch_idx}.png")

def save_masks_patches(dataloader, output_dir="output"):
    output_dir=os.path.join(output_dir, "masks")
    os.makedirs(output_dir, exist_ok=True)
    for batch_idx, (patches_batch, img_paths) in enumerate(tqdm(dataloader, desc="Processing batches", leave=True)):
            # patches_batch: (BATCH_SIZE, N_PATCHES, PATCH_SIZE, PATCH_SIZE)
            for img_idx, (image_patches, img_path) in enumerate(zip(patches_batch, img_paths)): 
                for patch_idx, patch in enumerate(image_patches):
                    patch = patch.detach().cpu().numpy()  
                    patch = patch.astype('uint8')
                    patch = Image.fromarray(patch)
                    img_name = os.path.basename(img_path)
                    patch.save(f"{output_dir}/{img_name}_patch_{patch_idx}.png")

def main():
    parser = argparse.ArgumentParser(description='Inference for bigger images')
    parser.add_argument('--model', type=str, default='MSMDFF_USE_SCMD', help='The model you want to use')
    parser.add_argument('--weights', type=str, default='None', help='Path to the model weights') 
    parser.add_argument('--file', type=str, default='None', help='Path to the split file') 
    parser.add_argument('--patch_size', type=int, default=512, help='Dimensions of the images patches')
    parser.add_argument('--batch_size', type=int, default=1, help='Dimension of batch')
    parser.add_argument('--masks', type=lambda x: x.lower() == 'true', default=False, help='If you want to have the masks patches')
    parser.add_argument('--output', type=str, default='output', help='Directory for outputs')

    args = parser.parse_args()
    model_name=args.model
    weights=args.weights
    file=args.file
    patch_size=args.patch_size
    batch_size=args.batch_size
    masks=args.masks
    output=args.output
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


    dataloader = load_dataloader(file, patch_size, batch_size, masks)

    if masks==False:
        model=load_model(model_name, weights, DEVICE)
        inference(model, dataloader, DEVICE, output_dir=output)
    else:
        save_masks_patches(dataloader,output_dir=output)

if __name__ == "__main__":
    main()
