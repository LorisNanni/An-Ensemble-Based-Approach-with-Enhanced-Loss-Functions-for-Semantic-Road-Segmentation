# --coding:utf-8--
# PROJECT_NAME:MSMDFF-Net_open
# file_name:__init__.py
# log_user:wychasee
# author:by **
# date:2024/4/4
# time:上午8:36
from .DeeoRoadMapper_segment import Model as DeepRoadMapper_segment