import os
from PIL import Image
import numpy as np
from utils.metrics_methods.metrics import Evaluator
import argparse
from tqdm import tqdm

parser = argparse.ArgumentParser(description='TESTING')
parser.add_argument('--path', type=str, default='./', help="Path to the directory containing 'predictions' and 'masks'")
parser.add_argument('--thresh', type=float, default=0.375, help='Threshold used')
parser.add_argument('--mask_ext', type=str, default='', help="Extension of mask images (e.g., .png, .jpg, .tif). If empty, use same extension as predictions.")

args = parser.parse_args()
folder_pred = os.path.join(args.path, "predictions")
folder_target = os.path.join(args.path, "masks")
thresh = args.thresh
file_names = os.listdir(folder_pred)
evaluator = Evaluator(2)

print('Using threshold:', thresh)

for file_name in tqdm(file_names, desc="Processing images", unit="file"):
    pred_path = os.path.join(folder_pred, file_name)
    
    base_name, pred_ext = os.path.splitext(file_name)  
    mask_ext = args.mask_ext if args.mask_ext else pred_ext 
    
    target_path = os.path.join(folder_target, base_name + mask_ext)

    if not os.path.exists(target_path):
        print(f"Warning: Mask not found for {file_name}, skipping...")
        continue

    pred_img = Image.open(pred_path)
    target_img = Image.open(target_path)

    if target_img.size != (512,512):
        target_img = target_img.resize((512, 512), Image.NEAREST)

    pred = np.array(pred_img) / 255.0
    target = np.array(target_img)
    unique_values = np.unique(target)

    if set(unique_values) == {0, 255}:  
        target = target / 255

    pred[pred >= thresh] = 1
    pred[pred < thresh] = 0
    target[target >= 0.5] = 1
    target[target < 0.5] = 0

    evaluator.add_batch_and_return_iou(target, pred)

Acc_t = evaluator.Pixel_Accuracy()
Acc_class_t = evaluator.Pixel_Accuracy_Class()
mIoU_t = evaluator.Mean_Intersection_over_Union()
IoU_t = evaluator.Intersection_over_Union()
Precision_t = evaluator.Pixel_Precision()
Recall_t = evaluator.Pixel_Recall()
F1_t = evaluator.Pixel_F1()

final_metrics = (
    f"Acc: {Acc_t}, Acc_class: {Acc_class_t}, mIoU: {mIoU_t}, IoU: {IoU_t}, "
    f"Precision: {Precision_t}, Recall: {Recall_t}, F1: {F1_t}\n"
)

results_file_path = os.path.join(args.path, f"results_{thresh}.txt")

with open(results_file_path, "w") as results_file:
    print(final_metrics.strip())  
    results_file.write(final_metrics)
