##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
## Created by: Wang Yuchuan
## School of Automation Engineering, University of Electronic Science and Technology of China
## Email: wang-yu-chuan@foxmail.com
## Copyright (c) 2017
## for paper: A Multiscale and Multidirection Feature Fusion Network for Road Detection From Satellite Imagery
# https://ieeexplore.ieee.org/document/10477437)
##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
'''import sys
args = sys.argv[1:]
import os
if args == []:
    os.environ['CUDA_VISIBLE_DEVICES'] = '0,1,2'
else:
    os.environ['CUDA_VISIBLE_DEVICES'] = args[0]'''
import sys
import os
os.environ['CUDA_VISIBLE_DEVICES']= '0' #ADDED 
# train frame
from utils.frame_work_general import MyFrame
# loss
from utils.loss_fct.dice_loss import DiceLoss
from utils.loss_fct.dice_bce_loss import dice_bce_loss
from utils.loss_fct.MSE_loss import MSE_loss
from utils.loss_fct.Lce_Ldice import Lce_Ldice_loss
####ADDED#########
from utils.loss_fct.topological_loss import topological_loss #TL
from utils.loss_fct.topological_road_curvatures_loss import topological_road_curvatures_loss #T2
from utils.loss_fct.modified_topological_road_curvatures_loss import modified_topological_road_curvatures_loss #T4
################
# metrics
from utils.metrics_methods.metrics import Evaluator
# tensorboard
from utils.tensorboard_display.tensorboard_base import Mytensorboard
# model_seclect
from model_seclect import Model_get
# model_file
from utils.train_support_fct.model_file_process import loadModelNames

# others
from utils.train_support_fct.others_process import *
import os,json,datetime,time,torch
from tqdm import trange
import numpy as np

#import cv2
####ADDED####
from PIL import Image #Substitute for cv2
#############

cfg_path = './cfg_file/cfg_link_to_data_api.json'

# load config
class CFG(object):
    def __init__(self):
        with open(cfg_path, mode='r', encoding='utf-8') as f:
            cfg_list = json.load(f)
        self.DIR_SETTING = cfg_list[0]['DIR_SETTING']
        self.DATA_SETTING = cfg_list[1]['DATA_SETTING']
        self.OPTIMIZER_SETTING = cfg_list[2]['OPTIMIZER_SETTING']
        self.TRAIN_SETTING = cfg_list[3]['TRAIN_SETTING']
        self.TEST_SETTING = cfg_list[4]['TEST_SETTING']
        self.BEI_ZHU = cfg_list[5]['BEI_ZHU']
        self.CONFIG_NAME = cfg_list[6]['CONFIG_NAME']

cfg = CFG()

'''if cfg.TRAIN_SETTING['DATA_TYPE'] == 'spacenet_512x512':
    from utils.dataloader._slice_loader.spaceNet_loader import loader_get

elif cfg.TRAIN_SETTING['DATA_TYPE'] == 'DeepGlobe_512x512':
    from utils.dataloader._slice_loader.deepGlobe_loader import loader_get

elif cfg.TRAIN_SETTING['DATA_TYPE'] == 'Massachusetts_512x512':
    from utils.dataloader._slice_loader.Massachusetts_loader import loader_get
else:
    print('dataLoader load error!', flush=True)
    exit(0)''' #Commented and moved below to make it work with command line parameters.

import random
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = True


import argparse
if __name__ == '__main__':
    # 设置随机数种子
    setup_seed(20)
    parser = argparse.ArgumentParser(description='training.')
    parser.add_argument('--local_rank', default=os.getenv('LOCAL_RANK', 0), type=int)
    parser.add_argument('-dis','--DISTRIBUTE', action='store_true', default=False)
    # parser.add_argument('--local_rank', default=os.getenv('LOCAL_RANK', -1), type=int)
    ####ADDED####
    parser.add_argument('--model', type=str, default=cfg.TRAIN_SETTING['MODEL_TYPE'], help='Name of the model to use')  
    parser.add_argument('--loss', type=str, default=cfg.OPTIMIZER_SETTING['LOSS_FCT'], help='Loss function to use') 
    parser.add_argument('--threshold', type=float, default=cfg.TRAIN_SETTING['IOU_THRESHOLD_LOSS'], help='Threshold value for the loss')
    parser.add_argument('--dataset', type=str, default=cfg.TRAIN_SETTING['DATA_TYPE'], choices=['spacenet_512x512', 'DeepGlobe_512x512', 'Massachusetts_512x512', 'test_512x512'],help='Dataset type to use')
    parser.add_argument('--lr', type=str, default=cfg.OPTIMIZER_SETTING['LR_SCHEDULER'], choices=['StepLR', 'MultiStepLR', 'ExponentialLR', 'CosineAnnealingLR', 'ReduceLRonPlateau', 'LambdaLR', 'POLY'], help='LR scheduler policy')
    parser.add_argument('--optimizer', type=str, default=cfg.OPTIMIZER_SETTING['OPTIMIZER'], choices=['SGD', 'ASGD', 'Rprop', 'Adagrad', 'Adadelta', 'RMSprop', 'Adam(AMSGrad)'], help='Optimizer choice')
    parser.add_argument('--k', type=int, default=None, help='Elements for every epoch') #ADDED
    #############
    args = parser.parse_args()
    cfg.TRAIN_SETTING['local_rank'] = args.local_rank
    cfg.TRAIN_SETTING["DISTRIBUTE"] = args.DISTRIBUTE
    ####ADDED####
    Model_select = args.model 
    loss_type = args.loss 
    thresh = args.threshold
    k = args.k #ADDED

    ####MOVED HERE####
    '''if args.dataset == 'spacenet_512x512':
        from utils.dataloader._slice_loader.spaceNet_loader import loader_get
        cfg.DIR_SETTING['train_sample']='data/train/SpaceNet'
        cfg.DIR_SETTING['root_dir']='data/train/SpaceNet'

    elif args.dataset == 'DeepGlobe_512x512':
        from utils.dataloader._slice_loader.deepGlobe_loader import loader_get
        cfg.DIR_SETTING['train_sample']='data/train/DeepGlobe'
        cfg.DIR_SETTING['root_dir']='data/train/DeepGlobe'

    elif args.dataset == 'Massachusetts_512x512':
        from utils.dataloader._slice_loader.Massachusetts_loader import loader_get
        cfg.DIR_SETTING['train_sample']='data/train/MassachusettsRoads'
        cfg.DIR_SETTING['root_dir']='data/train/MassachusettsRoads'

    elif args.dataset == 'test_512x512':
        from utils.dataloader._slice_loader.512_loader import loader_get
        cfg.DIR_SETTING['train_sample']='data/train/roadsegmentation'
        cfg.DIR_SETTING['root_dir']='data/train/roadsegmentation'
    else:
        print('dataLoader load error!', flush=True)
        exit(0)'''

    from utils.dataloader._slice_loader.aug_loader import loader_get #modified here to test k elements for the Massachusetts augmented dataset.
    cfg.DIR_SETTING['train_sample']='data/train/roadsegmentation'
    cfg.DIR_SETTING['root_dir']='data/train/roadsegmentation'

    ####Updating CFG values####
    cfg.TRAIN_SETTING['MODEL_TYPE']=args.model
    cfg.TRAIN_SETTING['DATA_TYPE']="test_512_512" #Modified for this file only. To test MS augmentation
    cfg.TRAIN_SETTING['IOU_THRESHOLD_LOSS']=args.threshold
    cfg.OPTIMIZER_SETTING['LOSS_FCT']=loss_type 
    cfg.OPTIMIZER_SETTING['LR_SCHEDULER']=args.lr 
    cfg.OPTIMIZER_SETTING['OPTIMIZER']=args.optimizer
    ###########################

    ####################   init para   ###############################
    beizhu = cfg.BEI_ZHU
    #Model_select = cfg.TRAIN_SETTING['MODEL_TYPE'] #Commented, now it is defined above
    TRAIN_IMG_SIZE = cfg.TRAIN_SETTING['TRAIN_IMG_SIZE']
    class_num = cfg.TRAIN_SETTING['CLASS_NUM']

    import platform
    _sysstr = platform.system()
    if (_sysstr == "Windows"):
        print("Call Windows tasks", flush=True)
    elif (_sysstr == "Linux"):
        print("Call Linux tasks", flush=True)

    try:
        test_run_frequence = cfg.TEST_SETTING["DISPLAY_FREQ"]
    except:
        test_run_frequence = 1 #兼容之前的版本

    train_size = cfg.DATA_SETTING["train_size"]  # 0.9 和 0.1
    random_state = cfg.DATA_SETTING["random_state"]
    BATCHSIZE_ALL_CARD = cfg.TRAIN_SETTING["BATCH_SIZE"]  # BATCHSIZE_PER_CARD为所有显卡一共的
    TEST_BATCH_SIZE = cfg.TEST_SETTING["BATCH_SIZE"]

    trainDataEnchance = cfg.DATA_SETTING['trainDataEnchance']
    valDataEnchance = cfg.DATA_SETTING['valDataEnchance']
    input_normalization = cfg.DATA_SETTING['input_normalization']
    image_dir = cfg.DIR_SETTING['root_dir']
    # label_dir = cfg.DIR_SETTING['label_dir'] 

    train_num_workers = cfg.TRAIN_SETTING["NUMBER_WORKERS"]
    val_num_workers = cfg.TEST_SETTING["NUMBER_WORKERS"]
    train_pin_memor = cfg.TRAIN_SETTING["TRAIN_PIN_MEMOR"]
    val_pin_memor = cfg.TEST_SETTING["TEST_PIN_MEMOR"]

    runType = cfg.TRAIN_SETTING["runType"]  
    # dataReadType = cfg.DATA_SETTING["dataReadType"]
    trainProcessdata_path = cfg.DIR_SETTING['trainProcessdata']
    OPTIMIZER_SETTING = cfg.OPTIMIZER_SETTING

    #NAME = '%s-Network-Configuration' % (cfg.CONFIG_NAME)  #网络配置 #Commented as new definition is below
    ####ADDED#########################################
    NAME = f"{Model_select}-{cfg.TRAIN_SETTING['DATA_TYPE']}-{loss_type}-{cfg.OPTIMIZER_SETTING['LR_SCHEDULER']}-{thresh}"
    ##################################################
    model_NAME = NAME.split('-')[0] 

    ############################################# model select ##########################################################
    model = Model_get(cfg_path = cfg_path, Model_select=Model_select) 
    ############################################# loss select ##########################################################
    #loss_type = cfg.OPTIMIZER_SETTING['LOSS_FCT'] #Commented as definition is now above
    for _loss_fct in [dice_bce_loss,\
                       DiceLoss,\
                       MSE_loss,\
                       Lce_Ldice_loss,\
                       topological_loss,\
                       topological_road_curvatures_loss, \
                       modified_topological_road_curvatures_loss, \
                       ]:#Losses are added here. If they have parameters, to be added in frame_work_general.py and in solver = MyFrame() in this file.
        if loss_type == _loss_fct.__name__:
            loss_fct = _loss_fct
            break
        else:loss_fct = None
    del _loss_fct

    #####ADDED for not implemented loss########
    if loss_fct == None:
        print("Loss not implemented")
        exit(0)
    ###########################################

    ############################################# init dir ##########################################################
    modelDir = trainProcessdata_path + '/' + NAME + '/weights/net_sate/'
    best_iou_modelDir = trainProcessdata_path + '/' + NAME + '/weights/best_iou/'
    test_out_src = trainProcessdata_path + '/' + NAME + '/weights/test_out/image_src/'
    test_out_lab = trainProcessdata_path + '/' + NAME + '/weights/test_out/predict/'

    intermediate_modelDir = trainProcessdata_path.replace("\\", "/") + '/' + NAME + '/logs/inter_parameters/'
    outer_parameters = trainProcessdata_path.replace("\\", "/") + '/' + NAME + '/logs/outer_parameters/'
    samples_dictDir = trainProcessdata_path.replace("\\", "/") + '/' + NAME + '/logs/samples_parameters/'

    os.makedirs(modelDir,exist_ok=True)
    os.makedirs(best_iou_modelDir,exist_ok=True)
    os.makedirs(test_out_src,exist_ok=True)
    os.makedirs(test_out_lab,exist_ok=True)

    os.makedirs(intermediate_modelDir,exist_ok=True)
    os.makedirs(outer_parameters,exist_ok=True)
    os.makedirs(samples_dictDir,exist_ok=True)

    ####################   init tensorboard   #######################
    tensorboard_Dir = trainProcessdata_path.replace("\\", "/") + '/' + NAME + '/tensorboard_info/'
    os.makedirs(tensorboard_Dir,exist_ok=True)
    my_board = Mytensorboard(tensorboard_Dir)
    ####################   end  ####################################

    ############################## load log  ################################################################
    log_write_flage = True
    if len(os.listdir(outer_parameters)) == 0:
        log_write_flage = True
        logDir = outer_parameters + NAME + '-' + str(datetime.datetime.now().strftime('%Y-%m-%d %H.%M.%S')) + '.log'
        mylog = open(logDir, 'w',encoding='utf-8')
        best_val_iou = 0
    else:
        log_write_flage = False
        _log_name = [_log_name for _log_name in os.listdir(outer_parameters) if '.log' in _log_name][0]
        logDir = outer_parameters + _log_name
        mylog = open(logDir, 'a+',encoding='utf-8')
    #### end ############################################################################################

    context = 'setting file: %s' % cfg.CONFIG_NAME + '\n' + \
              'Time        : %s' % str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) + '\n' + \
              'MODEL_TYPE  : %s' % Model_select + '\n' + \
              'Data_use    : %s' % image_dir + '\n' + \
              'Data_size    : %s' % cfg.TRAIN_SETTING['TRAIN_IMG_SIZE'] + '\n' + \
              'batch_size    : %s' % BATCHSIZE_ALL_CARD + '\n' + \
              'DataEnchance: %s - %s' % (trainDataEnchance, valDataEnchance) + '\n' + \
              'Input_normal: %s' % input_normalization + '\n' + \
              'OPTIMIZER_SETTING  : %s' % OPTIMIZER_SETTING + '\n' + \
              'Train_save  : %s' % modelDir + '\n' + \
              'other log   : %s' % beizhu + '\n' + \
              '########################### 分割线 #######################\n'
            #Modified this line #'MODEL_TYPE  : %s' % cfg.TRAIN_SETTING['MODEL_TYPE'] + '\n' + \
    print(context, flush=True)
    mylog.write(context) if log_write_flage == True else ''
    mylog.flush()
    # Define Dataloader
    opt = {
    "train_batchsize":BATCHSIZE_ALL_CARD,
    "val_batchsize":TEST_BATCH_SIZE,

    "train_num_workers":cfg.TRAIN_SETTING["NUMBER_WORKERS"],
    "val_num_workers":cfg.TEST_SETTING["NUMBER_WORKERS"],

    "train_pin_memor":cfg.TRAIN_SETTING["TRAIN_PIN_MEMOR"],
    "val_pin_memor":cfg.TEST_SETTING["TEST_PIN_MEMOR"],

    'shuffle':cfg.TRAIN_SETTING["shuffle"]
    }
    train_loader, val_loader = loader_get(cfg.DIR_SETTING['train_sample'],opt,k) #ADDED k
    cfg.TRAIN_SETTING["train_loader_size"] = len(train_loader)
    cfg.TRAIN_SETTING["val_loader_size"] = len(val_loader)
    ##################################   init model para  ####################################
    image_write_flage = False
    no_optim = 0  # 模型停止 计数器 
    total_epoch = cfg.TRAIN_SETTING["EPOCHS"] #Modified, now it depends on the configuration file.
    # train_epoch_best_loss = 10/10
    test_loss = 0
    global_step = float(0)
    save_flag = False
    solver = MyFrame(model, loss_fct, class_num=class_num,cfg=cfg, thresh=thresh, loss_type=loss_type) #ADDED thresh and loss_type parameters
    best_train_iou = 0

    best_iou = [[],[]]
    #### load log and model ###############################################################
    model_name, max_num, epoch, lr_current = loadModelNames(modelDir)
    ####ADDED#### if/else 
    if epoch >= total_epoch:
        print('\nThe network has already trained for '+ str(total_epoch) +' epochs \nThe training will now STOP\n', flush=True)
    else:
        if os.path.exists(model_name):
            solver.load(model_name)
            global_step, epoch, lr_current = max_num, epoch, lr_current
            solver.update_lr(lr_current)
            save_flag = True
            broken_flag = 1
            #print('加载 epoch {%d} 成功！\n' % epoch) #Commented
            print('\nPrevious model found. Training resumes from epoch {%d} \n' %epoch, flush=True) #ADDED
            cfg.OPTIMIZER_SETTING["LR_INIT"] = lr_current
            ####ADDED####
            if os.path.exists(os.path.join(best_iou_modelDir, 'best_iou_epoch.txt')):
                with open(os.path.join(best_iou_modelDir, 'best_iou_epoch.txt'), 'r') as f:
                    best_val_iou, best_epoch = map(float, f.read().split(','))
                print(f"\nBest IOU from previous run: {best_val_iou}, achieved at epoch {best_epoch} \n", flush=True)
            else:
                print("\nNo best IOU found\n", flush=True)
                best_val_iou = 0
            #############
        else:
            epoch = 0
            broken_flag = 0
            best_val_iou = 0
            #print('无保存模型，将从头开始训练！\n') #Commented
            print('No previous model found. Training starts', flush=True) #ADDED

        ################ big loop ###############################################################
        evaluator_train = Evaluator(2)
        evaluator_test = Evaluator(2)
        evaluator_train.reset()
        evaluator_test.reset()
        id_dict = {}

        remaining_time=''

        for epoch_ in range(epoch+1, total_epoch + 1):
            #epoch_ = epoch + 1 #Commented
            #print('\n\n---------- Epoch:' + str(epoch) + ' ----------') #Commented
            print('\n\n---------- Epoch:' + str(epoch_) + '/' + str(total_epoch) + ' ----------', flush=True) #Modified, shows at wich point the training is.
            train_epoch_loss = []
            train_epoch_iou = []
            train_epoch_id = [] 
            test_epoch_loss = []
            test_epoch_iou = []
            test_epoch_id = []

            train_loader.dataset.shuffle_subset() #ADDED for shuffling the k elements.

            ############ADDED FOR RESULTS###############
            src_out = test_out_src + 'epoch_%d' % epoch_
            #mkdir(src_out) #Commented for tests
            ############################################
            predict_out = test_out_lab + 'epoch_%d' % epoch_
            #mkdir(predict_out) #Commented for tests


            data_loader_iter = iter(train_loader)

            solver.net.train()  # 使能 BN层 drouptout层的 随机跳动
            with trange(len(train_loader), disable=False) as t:  # 实现进度条 #ADDED disable=. (True if you don't want the output bar.)
                epoch_time = np.zeros([len(train_loader)])
                for index in t:
                    time_start = time.time()
                    # train_sample = data_loader_iter.next()
                    train_sample = next(data_loader_iter)
                    if not list(train_sample['image'].shape)[-1] == cfg.TRAIN_SETTING['TRAIN_IMG_SIZE'][-1]: print('data_size error!!', flush=True)
                    solver.set_input(train_sample)
                    batch_loss_n, pred, logits = solver.optimize(index+1,epoch_)  #ADDED, it also returns the logits

                    with torch.no_grad():
                        # metric
                        batch_loss_n = batch_loss_n.cpu().data.numpy()
                        pred = pred.cpu().data.numpy().squeeze()
                        target = train_sample['label'].cpu().data.numpy().squeeze().astype(np.uint8)
                        pred[pred < thresh] = 0     
                        pred[pred >= thresh] = 1
                        batch_iou_n = evaluator_train.add_batch_and_return_iou(target, pred)

                        for train_single_id, train_single_loss, train_single_iou \
                                in zip(train_sample['id'], batch_loss_n, batch_iou_n):
                            train_epoch_id.append(train_single_id)
                            try:
                                train_epoch_loss.append(train_single_loss[0])
                            except:
                                train_epoch_loss.append(train_single_loss)
                            train_epoch_iou.append(train_single_iou)
                        train_batch_loss_show = batch_loss_n.mean(0).item() #ADDED .item(), to have a scalar instead that a array.
                        train_batch_iou_show = batch_iou_n.mean(0).item() #ADDED .item(), too have a scalar instead that a array.
                        train_epoch_loss_show = np.mean(train_epoch_loss)
                        train_epoch_iou_show = np.mean(train_epoch_iou)
                        global_step = global_step + 1

                        time_end = time.time()
                        epoch_time[index] = time_end - time_start
                        #last_time = ((len(train_loader)-index-1) + (total_epoch-epoch_-1)*len(train_loader)) *np.mean(epoch_time[:index+1]) #Commented
                        last_time = ((len(train_loader)-index-1) + (total_epoch-epoch_)*len(train_loader)) *np.mean(epoch_time[:index+1]) #ADDED
                        m,s = divmod(last_time,60)
                        h,m = divmod(m,60)
                        spend_time = '%dh:%dm:%ds'%(h,m,s)

                        remaining_time = spend_time #ADDED

                        t.set_description('training...loss:%.8f - iou:%.8f' % (train_batch_loss_show, train_batch_iou_show))
                        t.set_postfix(step=global_step, loss=train_epoch_loss_show, iou=train_epoch_iou_show, remaining_time=remaining_time)

            # Fast test during the training
            Acc = evaluator_train.Pixel_Accuracy()
            Acc_class = evaluator_train.Pixel_Accuracy_Class()
            mIoU = evaluator_train.Mean_Intersection_over_Union()
            IoU = evaluator_train.Intersection_over_Union()
            Precision = evaluator_train.Pixel_Precision()
            Recall = evaluator_train.Pixel_Recall()
            F1 = evaluator_train.Pixel_F1()
            evaluator_train.reset()
            print('train:', flush=True)
            print("Acc:{}, Acc_class:{}, mIoU:{}, IoU:{}, Precision:{}, Recall:{}, F1:{}, remaining_time:{}"
                .format(Acc, Acc_class, mIoU, IoU, Precision, Recall, F1, remaining_time), flush=True) #ADDED flush=True

            val_data_loader_iter = iter(val_loader)
            solver.net.eval()# 关闭 BN层 drouptout层的 随机跳动
            with trange(len(val_loader), disable=False) as t: #ADDED disable=. (True if you don't want the output bar.)
                for index in t:
                    # val_sample = val_data_loader_iter.next()
                    val_sample = next(val_data_loader_iter)
                    if val_sample['label'].shape[1] > 3:
                        val_sample['label'] = val_sample['label'][:, :3, :, :]  # 有的图像是四通道
                    predict_n, batch_loss_n, logits_n = solver.test_one_img(val_sample) #ADDED, it also returns the logits

                    # metric
                    pred = predict_n.cpu().data.numpy().squeeze()
                    target = val_sample['label'].cpu().data.numpy().squeeze().astype(np.uint8)
                    pred[pred < thresh] = 0
                    pred[pred >= thresh] = 1

                    ##########################ADDED TO SAVE IMAGES remember to un-comment the creation of these directories########################
                    '''image_id = val_sample['id']
                    output_image_name = f"{image_id}.png"
                    #Prediction
                    pred_img = (pred * 255).astype(np.uint8)
                    output_path = os.path.join(test_out_lab, output_image_name) 
                    #cv2.imwrite(output_path, pred_img)
                    image_pred = Image.fromarray(pred_img)
                    image_pred.save(output_path, format="PNG") #remember to decomment the creation of the directory at the beginning of the loop
                    #target
                    target_img = (target * 255).astype(np.uint8)
                    output_path = os.path.join(test_out_src, output_image_name) 
                    #cv2.imwrite(output_path, target_img)
                    image_target = Image.fromarray(target_img)
                    image_target.save(output_path, format='PNG') #remember to decomment the creation of the directory at the beginning of the loop
                    '''
                    ######################################################################

                    batch_iou_n = evaluator_test.add_batch_and_return_iou(target, pred) #IoU = evaluator.Intersection_over_Union()
                    # IOU LOSS 处理 ########################################################################################
                    for test_single_id, test_single_loss, test_single_iou in zip(val_sample['id'], batch_loss_n, batch_iou_n):
                        test_epoch_id.append(test_single_id)
                        try:
                            test_epoch_loss.append(test_single_loss[0])
                        except:
                            test_epoch_loss.append(test_single_loss)
                        test_epoch_iou.append(test_single_iou)

                    test_batch_loss_show = batch_loss_n.mean(0).item() #ADDED .item() to have a scalar instead that a array.
                    test_batch_iou_show = batch_iou_n.mean(0).item() #ADDED .item() to have a scalar instead that a array.
                    test_epoch_loss_show = np.mean(test_epoch_loss)
                    test_epoch_iou_show = np.mean(test_epoch_iou)

                    t.set_description('testing...loss:%.8f - iou:%.8f' % (test_batch_loss_show, test_batch_iou_show))
                    t.set_postfix(val_step=index, test_loss=test_epoch_loss_show, test_iou=test_epoch_iou_show,
                                lr=solver.lr_current)
                save_flag = False


            # Fast test during the testing
            Acc_t = evaluator_test.Pixel_Accuracy()
            Acc_class_t = evaluator_test.Pixel_Accuracy_Class()
            mIoU_t = evaluator_test.Mean_Intersection_over_Union()
            IoU_t = evaluator_test.Intersection_over_Union()
            Precision_t = evaluator_test.Pixel_Precision()
            Recall_t = evaluator_test.Pixel_Recall()
            F1_t = evaluator_test.Pixel_F1()
            evaluator_test.reset()

            if best_val_iou < IoU_t:#todo 该参数未保存   #Now best_val_iou is loaded in every case, see above
                best_val_iou = IoU_t
                best_iou[1].append([epoch_, best_val_iou])
            #########################ADDED##############################################################
                with open(os.path.join(best_iou_modelDir, 'best_iou_epoch.txt'), 'w') as f:
                    f.write(f'{best_val_iou},{epoch_}')
                print("\n NEW BEST IOU FOUND \n", flush=True)
                ####################ADDED###########################################################
                for filename in os.listdir(best_iou_modelDir):
                    if filename.endswith('.th'):
                        file_path = os.path.join(best_iou_modelDir, filename)
                        os.remove(file_path)
                # Save model in best_iou_modelDir
                solver.save(os.path.join(best_iou_modelDir, 'best_model_$%d$.th' % epoch_))
            ##############################################################################################

            if best_train_iou < IoU:
                best_train_iou = IoU
                best_iou[0].append([epoch_, best_train_iou])

            ################################## 模型权重级训练日志保存 与 学习率设置    #########################################
            now_time = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            print('(%d)--epoch:' % broken_flag, epoch_, '  --time:', now_time,
                '  --train_loss:', train_epoch_loss_show, ' --val_loss:', test_epoch_loss_show, \
                ' --train_iou:', train_epoch_iou_show, ' --val_iou:', test_epoch_iou_show,
                '  --lr:%s' % str(solver.lr_current), flush=True)

            print('Validation:', flush=True) #ADDED flush=True
            print("Acc:{}, Acc_class:{}, mIoU:{}, IoU:{}, Precision:{}, Recall:{}, F1:{}"
                .format(Acc_t, Acc_class_t, mIoU_t, IoU_t, Precision_t, Recall_t, F1_t), flush=True)

            #写入日志
            mylog.write('(%d)--epoch:'%broken_flag + str(epoch_).rjust(3,'0') + '  --time:' + now_time + \
                        '  --train_loss:' + str(train_epoch_loss_show).ljust(10,'0') + '  --val_loss:' + str(test_epoch_loss_show).ljust(10,'0') + \
                        '  --train_iou:%.8f'%(train_epoch_iou_show) + '  --val_iou:%.8f'%(test_epoch_iou_show) + \
                        '  --lr:%.16f' %(solver.lr_current) + \
                        '  --TestAcc:{}  --Acc_class:{}  --mIoU:{}  --IoU:{}  --Precision:{}  --Recall:{}  --F1:{}' \
                            .format(Acc_t, Acc_class_t, mIoU_t, IoU_t, Precision_t, Recall_t, F1_t,16) + \
                        # '  --TrainAcc:{}  --Acc_class:{}  --mIoU:{}  --IoU:{}  --Precision:{}  --Recall:{}  --F1:{}' \
                        #     .format(Acc, Acc_class, mIoU, IoU, Precision, Recall, F1) + \
                        '\n')
            # 清除 断点标记
            broken_flag = 0
            # 刷新缓冲区
            mylog.flush()
            # 保存模型

            ##############################ADDED###################################### to save only the last model
            for filename in os.listdir(modelDir):
                if filename.endswith('.pth') or filename.endswith('.th'):
                    file_path = os.path.join(modelDir, filename)
                    os.remove(file_path)
            #############################################################################

            solver.save(modelDir + str(global_step) + '_$%d$' % epoch_ + NAME + '$%.8f$.th' % solver.lr_current)


            my_board.Metrics_graph(metrics=['train_iou', 'train_loss', 'test_iou', 'test_loss', 'Acc',
                                            'Acc_class', 'mIoU', 'IoU', 'Precision', 'Recall', 'F1'],
                            metrics_values=[train_epoch_iou_show, train_epoch_loss_show,
                                            test_epoch_iou_show, test_epoch_loss_show,
                                            Acc_t, Acc_class_t, mIoU_t, IoU_t, Precision_t, Recall_t, F1_t],
                                            epoch=epoch_)
            ############################################################################################################

            ############################################################################################################


        print(mylog, 'Finish!', flush=True)
        print('Finish!', flush=True)
        mylog.close()

