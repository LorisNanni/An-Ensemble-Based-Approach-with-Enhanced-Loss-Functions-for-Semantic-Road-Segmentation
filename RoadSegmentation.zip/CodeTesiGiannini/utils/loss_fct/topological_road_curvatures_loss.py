#In the paper Known as T2

import torch
import torch.nn as nn
import torch.nn.functional as F
from skimage.morphology import skeletonize
import numpy as np

class topological_road_curvatures_loss(nn.Module):
    def __init__(self, weight=10, thresh=0.5):
        super(topological_road_curvatures_loss, self).__init__()
        self.cross_entropy=nn.BCELoss(reduction='none') 
        self.weight=weight
        self.thresh=thresh
    
    def directional_conv(self, B, f):
        C = F.conv2d(B, f, padding='same')
        C = torch.where(C != 2, 0, 1).float()
        return C

    def apply_filter(self, C, f):
        D = F.conv2d(C, f, padding='same')
        D = torch.clamp(D, max=self.weight)
        D = torch.where(D == 0, 1, D)
        return D

    def forward(self, pred, target):
        #(1-3)
        Cr = self.cross_entropy(pred, target)
        A = torch.where(pred >= self.thresh, 1.0, 0.0) 
        #Skeletonization of A
        A_np = A.cpu().numpy()
        B = np.zeros_like(A_np)
        for n in range(A_np.shape[0]):
            temp = skeletonize(A_np[n])
            temp = np.where(temp == True, 1, 0)
            B[n] = temp
        B = torch.from_numpy(B).to(pred.device).float()
        #(4-7)
        D, E, H, G, I, L, M, N = [torch.zeros_like(B).float() for _ in range(8)]

        #(8-16) Horizontal
        f_1 = torch.tensor([[1, 1, 1, 1, 1]], dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2= f_1 * self.weight
        C = self.directional_conv(B, f_1)
        D = self.apply_filter(C, f_2)

        #(17-25) Vertical
        f_1 = torch.tensor([[1], [1], [1], [1], [1]], dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        E = self.apply_filter(C, f_2)

        #(26-34) Right diagonal
        f_1 = torch.eye(5, dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        H = self.apply_filter(C, f_2)

        #(35-43) Left diagonal
        f_1 = torch.fliplr(torch.eye(5, dtype=torch.float)).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        G = self.apply_filter(C, f_2)

        # Curve Left-Down
        f_1 = torch.tensor([
            [0, 0, 0, 0, 0],
            [1, 1, 0, 0, 0],
            [0, 1, 1, 0, 0],
            [0, 0, 1, 1, 0],
            [0, 0, 0, 1, 0]
        ], dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        I = self.apply_filter(C, f_2)

        # Curve Left-Up
        f_1 = torch.tensor([
            [0, 0, 0, 1, 0],
            [0, 0, 1, 1, 0],
            [0, 1, 1, 0, 0],
            [1, 1, 0, 0, 0],
            [0, 0, 0, 0, 0]
        ], dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        L = self.apply_filter(C, f_2)

        # Curve Right-Down
        f_1 = torch.tensor([
            [0, 0, 0, 0, 0],
            [0, 0, 0, 1, 1],
            [0, 0, 1, 1, 0],
            [0, 1, 1, 0, 0],
            [0, 1, 0, 0, 0]
        ], dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        M = self.apply_filter(C, f_2)

        # Curve Right-Up
        f_1 = torch.tensor([
            [0, 1, 0, 0, 0],
            [0, 1, 1, 0, 0],
            [0, 0, 1, 1, 0],
            [0, 0, 0, 1, 1],
            [0, 0, 0, 0, 0]
        ], dtype=torch.float).unsqueeze(0).unsqueeze(0).to(pred.device)
        f_2 = f_1 * self.weight
        C = self.directional_conv(B, f_1)
        N = self.apply_filter(C, f_2)

        #(44-45) Fusion
        W = D + E + H + G + I + L + M + N 
        W = torch.clamp(W, max=self.weight) 
        W = torch.where(W==8, 1, W) 

        #(46-47) Loss calculation
        J = W * Cr
        batch_loss = J.mean([1,2,3]).view(target.size(0),target.size(1))
        return batch_loss, J.mean()
