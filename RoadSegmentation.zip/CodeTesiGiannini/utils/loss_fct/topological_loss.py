import torch
import torch.nn as nn
import torch.nn.functional as F
from skimage.morphology import skeletonize
import numpy as np

class topological_loss(nn.Module):
    def __init__(self, weight=10.0, thresh=0.5):
        super(topological_loss, self).__init__()
        self.weight=weight
        self.thresh=thresh

    def get_skeleton(self, img):
        img_np=img.cpu().numpy()
        skeleton=skeletonize(img_np).astype(float)
        return torch.tensor(skeleton, device=img.device, dtype=torch.float)
    
    def directional_conv(self, B, f):
        C=F.conv2d(B.unsqueeze(0), f.unsqueeze(0).unsqueeze(0),padding='same')
        C=torch.where(C!=2,0,1).float()
        return C

    def apply_filter(self,C,f):
        D=F.conv2d(C,f.unsqueeze(0).unsqueeze(0),padding='same')
        D=torch.clamp(D,max=self.weight)
        D[D==0]=1.0
        return D
    
    def __call__(self, pred, target):
        batch_size=pred.shape[0]
        total_loss=torch.tensor(0.0).to(pred.device)

        for mini_batch_num in range(batch_size):
            Z=pred[mini_batch_num,:,:,:].squeeze()
            Cr=F.binary_cross_entropy(pred[mini_batch_num], target[mini_batch_num], reduction='none')

            Z=(Z>=self.thresh).float() 

            B=self.get_skeleton(Z)

            #Horizontal direction
            f=torch.ones(1,5,dtype=torch.float).to(pred.device)
            C=self.directional_conv(B,f)
            f=f*self.weight
            D=self.apply_filter(C,f)

            #Vertical direction
            f=torch.ones(5,1, dtype=torch.float).to(pred.device)
            C=self.directional_conv(B,f)
            f=f*self.weight
            E=self.apply_filter(C,f)

            #\ direction
            f=torch.eye(5, dtype=torch.float).to(pred.device)
            C=self.directional_conv(B,f)
            f=f*self.weight
            H=self.apply_filter(C,f)

            #/ direction
            f=torch.fliplr(torch.eye(5, dtype=torch.float)).to(pred.device)
            C=self.directional_conv(B,f)
            f=f*self.weight
            G=self.apply_filter(C,f)

            #fusion
            W=D+E+H+G
            W=torch.clamp(W, max=self.weight) 
            W[W==4]=1

            J=W*Cr
            batch_loss= J.mean()
            total_loss+=batch_loss

        loss=total_loss/batch_size
        return loss.view(1,1), loss