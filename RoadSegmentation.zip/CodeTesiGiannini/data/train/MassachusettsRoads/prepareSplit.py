input_file = input('Input file (If it is train.txt or val.txt change the transfromed line in script): ')  
output_file = input('Output file: ')

with open(input_file, "r") as infile:
    lines = infile.readlines()
with open(output_file, "w") as outfile:
    for line in lines:
        X = line.strip()
        transformed_line = f"test/{X} @test_labels/{X}\n" #test
        #transformed_line = f"train/{X} @train_labels/{X}\n"" #train and val
        outfile.write(transformed_line)
